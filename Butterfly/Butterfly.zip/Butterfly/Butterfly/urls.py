"""Butterfly URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from ButterflyApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('',views.index,name='index'),
    path('about.html/',views.about,name='about'),
    path('english.html/',views.english,name='english'),
    path('contact_form.html/',views.contact_us,name='contact_us'),
    path('mathematics.html/',views.mathematics,name='mathematics'),
    path('hindi.html/',views.hindi,name='hindi'),
    path('signup/',views.signup,name='signup'),
    path('logout/',views.logout,name='logout'),
    path('add_item.html/',views.cart_system,name='cart_system'),
    path('tourism/',views.tourism,name='tourism'),
    path('general_knowledge.html/',views.general_knowledge,name='general_knowledge'),

]
