from django.apps import AppConfig


class ButterflyappConfig(AppConfig):
    name = 'ButterflyApp'
