from django.contrib import admin
from ButterflyApp.models import GeneralKnowledge
# Register your models here.
admin.site.register(GeneralKnowledge)
